﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NewHospitalManagementSystem.Models;
using Hospital_medical_WebAPI.Service;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Hospital_medical_WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class MedicalHistoryController : ControllerBase
    {
        private readonly IMedicalHistoryService _service;

        public MedicalHistoryController(IMedicalHistoryService service)
        {
            _service = service;
        }

        // GET: api/MedicalHistory
        [HttpGet]
        public async Task<ActionResult<IEnumerable<MedicalHistory>>> GetMedicalHistories()
        {
            var medicalHistories = await _service.GetAllMedicalHistories();
            return Ok(medicalHistories);
        }

        // GET: api/MedicalHistory/5
        [HttpGet("{id}")]
        public async Task<ActionResult<MedicalHistory>> GetMedicalHistory(int id)
        {
            var medicalHistory = await _service.GetMedicalHistoryById(id);
            if (medicalHistory == null)
            {
                return NotFound();
            }
            return Ok(medicalHistory);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutMedicalHistory(int id, MedicalHistory medicalHistory)
        {
            if (id != medicalHistory.PatientId)
            {
                return BadRequest();
            }

            try
            {
                await _service.UpdateMedicalHistory(id, medicalHistory);
            }
            catch (DbUpdateConcurrencyException)
            {
                var existingMedicalHistory = await _service.GetMedicalHistoryById(id);
                if (existingMedicalHistory == null)
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/MedicalHistory
        [HttpPost]
        public async Task<ActionResult<MedicalHistory>> PostMedicalHistory(MedicalHistory medicalHistory)
        {
            var createdMedicalHistory = await _service.AddMedicalHistory(medicalHistory);
            return CreatedAtAction("GetMedicalHistory", new { id = createdMedicalHistory.PatientId }, createdMedicalHistory);
        }

        // DELETE: api/MedicalHistory/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteMedicalHistory(int id)
        {
            var success = await _service.DeleteMedicalHistory(id);
            if (!success)
            {
                return NotFound();
            }

            return NoContent();
        }
    }
}