﻿using NewHospitalManagementSystem.Models;

using Microsoft.EntityFrameworkCore;

using System;

using System.Collections.Generic;

using System.Linq;

using System.Threading.Tasks;

using NewHospitalManagementSystem.Exceptions;

public class AppointmentService : IAppointmentService
{
    private readonly IAppointmentRepository _appointmentRepository;

    public AppointmentService(IAppointmentRepository appointmentRepository)
    {
        _appointmentRepository = appointmentRepository;
    }

    public async Task<Appointment> BookAppointment(AppointmentBookingDto bookingDto)
    {
        // Your existing logic for booking an appointment
        var appointment = new Appointment
        {
            DoctorId = bookingDto.DoctorId,
            PatientId = bookingDto.PatientId,
            AppointmentDate = bookingDto.AppointmentDate,
            AppointmentTime = bookingDto.AppointmentTime,
            Status = "Scheduled"
        };

        return await _appointmentRepository.BookAppointmentAsync(appointment);
    }

    public async Task<IEnumerable<Appointment>> GetAppointmentsById()
    {
        return await _appointmentRepository.GetAllAppointmentsAsync();
    }

    public async Task<IEnumerable<Appointment>> GetAppointments()
    {
        return await _appointmentRepository.GetAllAppointmentsAsync();
    }

    public async Task<IEnumerable<Appointment>> GetAppointmentsByDoctorId(int doctorId)
    {
        return await _appointmentRepository.GetAllAppointmentsAsync();
    }

    public async Task<bool> CancelAppointment(int appointmentId)
    {
        return await _appointmentRepository.DeleteAppointmentAsync(appointmentId);
    }
}